import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

// Types derived from schema
type Upload = z.infer<typeof api.uploads.list.responses[200]>[number];
type GeometryResponse = z.infer<typeof api.uploads.process.responses[200]>;
type ProcessInput = z.infer<typeof api.uploads.process.input>;

export function useUploads() {
  return useQuery({
    queryKey: [api.uploads.list.path],
    queryFn: async () => {
      const res = await fetch(api.uploads.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch uploads");
      return api.uploads.list.responses[200].parse(await res.json());
    },
  });
}

export function useUpload(id: number) {
  return useQuery({
    queryKey: [api.uploads.get.path, id],
    queryFn: async () => {
      if (!id) return null;
      const url = buildUrl(api.uploads.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch upload");
      return api.uploads.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateUpload() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (formData: FormData) => {
      // Direct fetch for multipart/form-data
      const res = await fetch(api.uploads.create.path, {
        method: "POST",
        body: formData,
        credentials: "include",
        // Note: Do NOT set Content-Type header manually for FormData, 
        // fetch will set it with the boundary
      });
      
      if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        throw new Error(error.message || "Failed to upload file");
      }
      return api.uploads.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.uploads.list.path] }),
  });
}

export function useProcessUpload(id: number) {
  return useMutation({
    mutationFn: async (data: ProcessInput) => {
      const url = buildUrl(api.uploads.process.path, { id });
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 404) throw new Error("Upload not found");
        throw new Error("Failed to process geometry");
      }
      return api.uploads.process.responses[200].parse(await res.json());
    },
  });
}
