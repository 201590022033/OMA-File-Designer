
import { pgTable, text, serial, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const lenses = pgTable("lenses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  omaContent: text("oma_content").notNull(),
  parsedMetadata: jsonb("parsed_metadata"), // Store basic info like TRCFMT
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertLensSchema = createInsertSchema(lenses).omit({ 
  id: true, 
  createdAt: true,
  parsedMetadata: true 
});

export type Lens = typeof lenses.$inferSelect;
export type InsertLens = z.infer<typeof insertLensSchema>;

export type CreateLensRequest = InsertLens;
export type LensResponse = Lens;
